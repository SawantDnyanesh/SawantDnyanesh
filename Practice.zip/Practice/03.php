<?php
    $str = "String";
    $st = "Hey I am Samael Samael Samael";
    echo $str;
    echo "<br>";
    $l = strlen($str);
    echo "Length of string is : " .$l . " Thanks";
    echo "<br>";
    echo "Words that include in string is : " .str_word_count($str) ;
    echo "<br>";
    echo "The reverse string is : " .strrev($str) ; 
    echo "<br>";
    echo "The search for string is : " .strpos($st, "am") ; 
    echo "<br>";
    echo "The replace string is : " .str_replace("Samael","King",$st) ; 

    // echo $l;
?>
