<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>02</title>
</head>
<style>
    *{
        margin : 0;
        padding : 0;
    }
    .container{
        max-width : 80%;
        background-color : cyan;
        margin : auto;
        padding : 25px;
    }
</style>
<body>
    <div class="container">
        <h1>Lets learn about php</h1>
        This is a container
        <?php
        //If else
        echo "<br>";
        $a = 7;
        if($a>18){
            echo "You can drive";
        }
        else if($a==7){
            echo "Ghar pe reh";
        }
        else{
            echo "Cannot Drive";
        }
        echo "<br>";
        ?>
        <?php
        //Array
        $ab = array("Python","C++","JS","php","HTML");

        echo $ab[0];
        echo "<br>";

        echo $ab[1];
        echo "<br>";

        echo $ab[2];
        echo "<br>";

        echo $ab[3];
        echo "<br>";

        echo $ab[4];
        echo "<br>";

        echo count($ab);
        echo "<br>";
        ?>
        <?php
        // Loops
        $a = 0;
        while ($a <= 10) {
            echo "Vanlu is :";
            echo $a;
            echo "<br>";
            $a++;
        }
        
        
        //Array used in while loop
        $a = 0;
        while ($a < count($ab)) {
            echo "Vanlu is :";
            echo $ab[$a];
            echo "<br>";
            $a++;
        }
        
        
        //do while loop
        $a = 0;
        do{
            echo "Vanlu is :";
            echo $a;
            echo "<br>";
            $a++;
        } while ($a <= 10);


        // for loop
        for ($i=0 ; $i<10 ;$i++) {
            echo "value = ";
            echo $i;
            echo "<br>";
        }

        //for each
        foreach ($ab as $v) {
            echo "Value is : ";
            echo $v;
            echo "<br>";
        }
        ?>
        <?php
        //function
        function print5(){
            echo "<br>SAMAEL";
        }
        print5();
        print5();
        print5();

        function print_num($n){
            echo "<br>Your number is :";
            echo $n;
        }
        print_num(8);
        print_num(25);
        print_num(30);
        ?>
    </div>
    
</body>
</html>
