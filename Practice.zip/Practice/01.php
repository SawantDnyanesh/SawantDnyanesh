<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>01</title>
</head>
<body>
    <div class="container">
        This is my 1st php website
    <?php
        define('D' ,7);
        // Single line comment
        /*
        multi 
        line 
        comment
        */
        echo "He website me banavlay using php";
        echo "<br>";
    ?>
    <?php
        echo "Hellow World";
        $variable1 = 5;
        echo "<br>";
        $variable2 = 10;
        echo "<br>";
        echo $variable1;
        echo "<br>";
        echo $variable2;
        echo "<br>";
        echo $variable1 + $variable2;
        echo "<br>";


        // Operators in php
        // Arithmetic Operator
        echo "<h1>Arithmetic Operator</h1>";
        echo "Variable1 + Variable2 = ";
        echo $variable1 + $variable2;
        echo "<br>";
        echo "Variable1 - Variable2 = ";
        echo $variable1 - $variable2;
        echo "<br>";
        echo "Variable1 * Variable2 = ";
        echo $variable1 * $variable2;
        echo "<br>";
        echo "Variable1 / Variable2 = ";
        echo $variable1 / $variable2;
        echo "<br>";
        echo "Variable1 ** Variable2 = ";
        echo $variable1 ** $variable2;
        echo "<br>";


        // Assignment Operator
        echo "<h1>Assignment Operator</h1>";
        $a = $variable1;
        echo "New variable value is ";
        echo $a;
        echo "<br>";

        $a += 1;
        echo $a;
        echo "<br>";

        $a -= 1;
        echo $a;
        echo "<br>";

        $a *= 2;
        echo $a;
        echo "<br>";

        $a /= 2;
        echo $a;
        echo "<br>";


        // Comparison Operator
        echo "<h1>Comparision Opperator</h1>";
        echo "The value of 1==4 is ";
        echo var_dump(1==4);
        echo "<br>";

        echo "The value of 1!=4 is ";
        echo var_dump(1!=4);
        echo "<br>";

        echo "The value of 1>=4 is ";
        echo var_dump(1>=4);
        echo "<br>";

        echo "The value of 1<=4 is ";
        echo var_dump(1<=4);
        echo "<br>";

        echo "The value of 1<4 is ";
        echo var_dump(1<4);
        echo "<br>";

        echo "The value of 1>4 is ";
        echo var_dump(1>4);
        echo "<br>";


        // Increment/Decrement Operator
        echo "<h1>Increment/Decrement Operator</h1>";
        echo "Initial value of Variable is ";
        echo $a;
        echo "<br>";
        
        $a++;
        echo $a;
        echo "<br>";
        
        $a--;
        echo $a;
        echo "<br>";
        
        ++$a;
        echo $a;
        echo "<br>";
        
        --$a;
        echo $a;
        echo "<br>";
        
        
        // Logical Operator
        echo "<h1>Logical Operator</h1>";
        //and (&&)
        $b = (true and true);
        echo var_dump($b);
        echo "<br>";

        $b = (true && true);
        echo var_dump($b);
        echo "<br>";
        echo "<br>";


        //or (||)
        //its like truth table of or


        //xor 
        $b = (true xor true);
        echo var_dump($b);
        echo "<br>";

        $b = (false xor false);
        echo var_dump($b);
        echo "<br>";

        $b = (true xor false);
        echo var_dump($b);
        echo "<br>";

        $b = (false xor true);
        echo var_dump($b);
        echo "<br>";



        //! // this means not operator it is also like its truth table
        
    ?>
    <?php
    // Data types in php
    echo "<h1>Data types in php</h1>";
        // 1. String
            $c = "This is a string";
            echo var_dump($c);
            echo "<br>";


        // 2. Integer
            $d = 5;
            echo var_dump($d);
            echo "<br>";


        // 3. Float
            $e = 5.5;
            echo var_dump($e);
            echo "<br>";

        // 4. Boolean
            $f = true;
            echo var_dump($f);
            echo "<br>";

        // 5. Array
            $g = [1,2,5,4,7];
            echo var_dump($g);
            echo "<br>";

        // 6. Object
        

        echo "<br>";
        echo "We can assign a constant value using 'define' and when we call that value it will shown us <br>"; 
        echo D;
    ?>
    </div>
</body>
</html>